package com.company.encapsulation_ex.domain;

public enum Format {JSON, TEXT}