package com.company.encapsulation.service;

import com.company.encapsulation.entity.User;
//Handles block storage
public class UserStorageService {

    public void allocateStorage(User usr, long size) {
        //allocate storage space
    }
}