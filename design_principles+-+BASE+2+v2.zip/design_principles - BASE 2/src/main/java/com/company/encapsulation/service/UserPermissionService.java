package com.company.encapsulation.service;

import com.company.encapsulation.entity.User;
//Permission management
public class UserPermissionService {

    public void grantPermission(User user, String permission) {
        //grant permission
    }
}