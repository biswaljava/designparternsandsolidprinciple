package com.company.codetointerface.entity;

public interface Employee {
    
	double getCompensation();
	
	void setCompensation(double amount);
	
	String getDesignation();
	
	Long getEmployeeId();
}