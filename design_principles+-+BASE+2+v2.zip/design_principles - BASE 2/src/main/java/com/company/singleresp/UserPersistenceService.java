package com.company.singleresp;

public class UserPersistenceService {

	
}
