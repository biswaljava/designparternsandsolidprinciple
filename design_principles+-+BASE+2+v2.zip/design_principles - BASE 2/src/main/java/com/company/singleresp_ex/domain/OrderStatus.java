package com.company.singleresp_ex.domain;

public enum OrderStatus { CREATED, PLACED, CANCELED, DELIEVERED}
