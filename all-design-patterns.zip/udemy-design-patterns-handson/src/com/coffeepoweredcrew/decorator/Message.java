package com.coffeepoweredcrew.decorator;

//Base interface or component
public interface Message {

	String getContent();
	
}
