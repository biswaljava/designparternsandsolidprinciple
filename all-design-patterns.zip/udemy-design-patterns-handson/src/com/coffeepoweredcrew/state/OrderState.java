package com.coffeepoweredcrew.state;

//Abstract state
public interface OrderState {

	double handleCancellation();
}
